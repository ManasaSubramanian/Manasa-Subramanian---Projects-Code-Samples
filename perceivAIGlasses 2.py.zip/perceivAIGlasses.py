#import
import RPi.GPIO as GPIO
import time
import base64
import sys
import os
os.environ["PULSE_SERVER"] = "unix:/run/user/1000/pulse/native"
os.environ["SDL_AUDIODRIVER"] = "pulseaudio"
from gtts import gTTS
import pygame
import subprocess
from openai import OpenAI


#define GPIO pins
TouchPin = 16 

TRIG_front = 11       
ECHO_front = 12       

TRIG_left = 13
ECHO_left = 15

TRIG_right = 18
ECHO_right = 22


#global variables
temp = 0
tmp = 1
state = False


#variables for image recognition
client = OpenAI(api_key="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")  #Replace with real key
MODEL = "gpt-5-nano-2025-08-07"      
IMAGE_PATH = "captured_image.jpg"
RESOLUTION = "640x480"             


def setup():
    GPIO.setmode(GPIO.BOARD) # Numbers GPIOs by physical location

    #setup for touch sensor
    GPIO.setup(TouchPin, GPIO.IN, pull_up_down=GPIO.PUD_UP)

    # Setup for ultrasonic sensors
    GPIO.setup(TRIG_front, GPIO.OUT)
    GPIO.setup(ECHO_front, GPIO.IN)

    GPIO.setup(TRIG_left, GPIO.OUT)
    GPIO.setup(ECHO_left, GPIO.IN)

    GPIO.setup(TRIG_right, GPIO.OUT)
    GPIO.setup(ECHO_right, GPIO.IN)


#_____________________________________________________________________

#TOUCH SENSOR METHODS

'''
When the touch sensor is pressed, the glasses power on
The touch sensor methods record when the glasses are on or off
This information is sent to the main method to run the rest of the program
'''

def Print_Status(x):
    global tmp
    global state
    if x != tmp:
        if x == 0:
            print('    **********')
            print('    *     ON *')
            print('    **********')
            state = True
        if x == 1:
            print('    **********')
            print('    * OFF    *')
            print('    **********')
            state = False
        tmp = x
    return state

def switch_loop():
    Print_Status(GPIO.input(TouchPin))
    return state

def destroy():
    GPIO.cleanup()


#____________________________________________________________________

#ULTRASONIC SENSOR METHODS
    
'''
The ultrasonic sensors detect the distance to an object
The glasses have 3 ultrasonics -- on the front, left, and right
If the side with the lowest distance to an object is less than 2 meters, then a message is sent to be read out
Additionally, if the front side has the lowest distance to an object and is less than 2 meters from the object, it will capture an image
'''
    
    
def distance(TRIG, ECHO):
    GPIO.output(TRIG, False)
    time.sleep(0.000002)

    GPIO.output(TRIG, True)
    time.sleep(0.00001)
    GPIO.output(TRIG, False)

    # Wait for echo start (timeout protection added)
    timeout = time.time() + 0.02
    while GPIO.input(ECHO) == 0:
        if time.time() > timeout:
            return 9999  # return very large distance if no signal
    pulse_start = time.time()

    # Wait for echo end (timeout protection added)
    timeout = time.time() + 0.02
    while GPIO.input(ECHO) == 1:
        if time.time() > timeout:
            return 9999
    pulse_end = time.time()

    pulse_duration = pulse_end - pulse_start
    distance_cm = pulse_duration * 34000 / 2
    return distance_cm


def Distance_loop():
    #while True:
        # measuring distance on all 3 sides
        dis_front = distance(TRIG_front, ECHO_front)
        print('front', dis_front, 'cm')
        dis_left = distance(TRIG_left, ECHO_left)
        print('left', dis_left, 'cm')
        dis_right = distance(TRIG_right, ECHO_right)
        print('right', dis_right, 'cm')

        # find the smallest distance
        min_distance = min(dis_front, dis_left, dis_right)

        # Determine which direction matched the min_distance
        if min_distance == dis_front:
            direction = "front"
        elif min_distance == dis_left:
            direction = "left"
        else:
            direction = "right"

        
        if min_distance < 200:  # if the object is within 2 meters
            text_to_speech('obstruction on ' + direction)
            if direction == "front":
                image()
                
        time.sleep(0.1)


#________________________________________________________________

#IMAGE CAPTURE METHODS
        
'''
The camera is instructed to capture an image
The image is then saved as a jpg
The image is then sent to OpenAI to identify the obstruction
Then, the message from OpenAI is read out loud to the user
'''
    
def capture_image(path: str):
    subprocess.run(["fswebcam", "-r", RESOLUTION, "-S", "2", "--no-banner", path], check=True)

def to_data_url(path: str) -> str:
    with open(path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode("utf-8")
    return f"data:image/jpeg;base64,{b64}"

def extract_text(resp):
    text = getattr(resp, "output_text", None)
    if text:
        return text.strip()
    try:
        for item in getattr(resp, "output", []):
            for part in getattr(item, "content", []):
                if getattr(part, "type", None) in ("output_text", "text") and getattr(part, "text", None):
                    return part.text.strip()
    except Exception:
        pass
    try:
        return resp.model_dump_json(indent=2)
    except Exception:
        return str(resp)

def image():
    try:
        IMAGE_PATH = "captured_image.jpg"
        capture_image(IMAGE_PATH)
        data_url = to_data_url(IMAGE_PATH)

        #the prompt sent to OpenAI:
        prompt = (
            "Reply with EXACTLY ONE clear sentence (<= 12 words) "
            "this is the view of a person. What is the one main obstruction that is closest in the image? Mention direction if applicable. Begin response with 'The obstruction in front of you is' and then state the object."
        )

        resp = client.responses.create(
            model="gpt-5-nano-2025-08-07",
            reasoning={"effort": "low"},
            max_output_tokens=1024,
            input=[{
                "role": "user",
                "content": [
                    {"type": "input_text", "text": prompt},
                    {"type": "input_image", "image_url": data_url}
                ]
            }],
        )

        message = extract_text(resp)
        text_to_speech(message)
        
    except Exception as e:
        print("ERROR:", repr(e), file=sys.stderr)
        raise
        
def text_to_speech(message):
    print(message)
    myObj = gTTS(text=message, lang='en')
    myObj.save("output.mp3")
    pygame.mixer.init()

    # Load the audio file
    pygame.mixer.music.load("output.mp3")

    # Play the audio
    pygame.mixer.music.play()

    # Keep the program running until the audio is finished
    while pygame.mixer.music.get_busy():
        continue

        

#________________________________________________________________

#main method

if __name__ == '__main__':
    setup()
    try:
        while True:
            status = switch_loop()
            if status:
                Distance_loop()
    except KeyboardInterrupt:
        destroy()


